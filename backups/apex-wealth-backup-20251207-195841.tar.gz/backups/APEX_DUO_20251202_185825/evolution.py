
import random
import copy
import json
from typing import List, Dict
from strategies.generic import GenericStrategy

class EvolutionEngine:
    def __init__(self):
        self.population_size = 50
        self.mutation_rate = 0.2
        self.generation_count = 0
        self.population = []
        
        self.INDICATORS = {
            "price": ["close", "sma50", "sma200", "bb_lower"],
            "momentum": ["rs_trend", "rs_ratio", "cci"],
            "oscillator": ["rsi2", "rsi14", "adx", "stoch_k"],
            "volatility": ["atr14", "bb_width"],
            "volume": ["volume", "vol_ma20"]
        }
        self.OPERATORS = [">", "<"]

    def _random_rule(self):
        cat = random.choice(list(self.INDICATORS.keys()))
        col = random.choice(self.INDICATORS[cat])
        op = random.choice(self.OPERATORS)
        val = 0
        if "rsi" in col: val = random.randint(5, 95)
        elif "vix" in col: val = random.randint(15, 40)
        elif "adx" in col: val = random.randint(20, 40)
        elif "bb_width" in col: val = round(random.uniform(0.1, 0.5), 2)
        elif "cci" in col: val = random.choice([-100, 0, 100])
        return {"col": col, "op": op, "val": val}

    def generate_initial_population(self):
        pass

    def mutate(self, genome: Dict) -> Dict:
        mutant = copy.deepcopy(genome)
        mutant["name"] = mutant["name"] + "_mut"
        r = random.random()
        
        if r < 0.3:
            # TIME STOP EXPANSION
            # To hit 5% profit, we need longer hold times.
            # Shifting range from [5-20] to [20-60].
            mutant["time_stop"] = random.choice([20, 25, 30, 35, 40, 45, 50, 60])
            
        elif r < 0.5:
            # PROFIT TARGET TUNING
            # Focusing on the 5% - 15% range
            if "exit_rules" in mutant:
                found = False
                for rule in mutant["exit_rules"]:
                    if rule.get("type") == "profit_target":
                        found = True
                        curr = float(rule.get("val", 1.06))
                        # Mutate
                        new_val = curr + random.choice([-0.01, 0.01, 0.02, 0.05])
                        # Keep it between 1.05 and 1.25
                        rule["val"] = round(max(1.05, min(1.25, new_val)), 2)
                
                # If no target, add one
                if not found and random.random() < 0.5:
                    mutant["exit_rules"].append({"type": "profit_target", "val": 1.07})
                    
        elif r < 0.7:
            # ENTRY RULE TWEAKS
            if mutant.get("entry_rules"):
                idx = random.randint(0, len(mutant["entry_rules"])-1)
                mutant["entry_rules"][idx] = self._random_rule()
                
        else:
            mutant["stop_loss_atr"] = round(random.uniform(3.0, 7.0), 1)
            
        return mutant

    def evolve(self, ranked):
        self.generation_count += 1
        survivors = [r["genome"] for r in ranked[:5]]
        next_gen = survivors[:]
        while len(next_gen) < self.population_size:
            # Prefer mutation over crossover to explore new Profit/Time parameters
            next_gen.append(self.mutate(random.choice(survivors)))
        self.population = next_gen
        return next_gen
